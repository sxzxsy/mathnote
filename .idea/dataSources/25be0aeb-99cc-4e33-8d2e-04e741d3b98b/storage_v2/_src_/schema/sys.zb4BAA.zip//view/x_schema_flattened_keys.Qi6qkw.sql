create definer = `mysql.sys`@localhost view x$schema_flattened_keys as
select `statistics`.`TABLE_SCHEMA`                                                                     AS `TABLE_SCHEMA`,
       `statistics`.`TABLE_NAME`                                                                       AS `TABLE_NAME`,
       `statistics`.`INDEX_NAME`                                                                       AS `INDEX_NAME`,
       max(`statistics`.`NON_UNIQUE`)                                                                  AS `non_unique`,
       max(if(isnull(`statistics`.`SUB_PART`), 0, 1))                                                  AS `subpart_exists`,
       group_concat(`statistics`.`COLUMN_NAME` order by `statistics`.`SEQ_IN_INDEX` ASC separator
                    ',')                                                                               AS `index_columns`
from `information_schema`.`STATISTICS`
where ((`statistics`.`INDEX_TYPE` = 'BTREE') and
       (`statistics`.`TABLE_SCHEMA` not in ('mysql', 'sys', 'INFORMATION_SCHEMA', 'PERFORMANCE_SCHEMA')))
group by `statistics`.`TABLE_SCHEMA`, `statistics`.`TABLE_NAME`, `statistics`.`INDEX_NAME`;

