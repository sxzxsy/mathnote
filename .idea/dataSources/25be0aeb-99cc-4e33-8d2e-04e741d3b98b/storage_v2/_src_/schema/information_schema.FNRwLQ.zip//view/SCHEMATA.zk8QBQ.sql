create view SCHEMATA as
select (`cat`.`name` collate utf8_tolower_ci) AS `CATALOG_NAME`,
       (`sch`.`name` collate utf8_tolower_ci) AS `SCHEMA_NAME`,
       `cs`.`name`                            AS `DEFAULT_CHARACTER_SET_NAME`,
       `col`.`name`                           AS `DEFAULT_COLLATION_NAME`,
       NULL                                   AS `SQL_PATH`
from (((`mysql`.`schemata` `sch` join `mysql`.`catalogs` `cat`
        on ((`cat`.`id` = `sch`.`catalog_id`))) join `mysql`.`collations` `col`
       on ((`sch`.`default_collation_id` = `col`.`id`))) join `mysql`.`character_sets` `cs`
      on ((`col`.`character_set_id` = `cs`.`id`)))
where can_access_database(`sch`.`name`);

