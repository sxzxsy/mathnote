create view KEY_COLUMN_USAGE as
(select (`cat`.`name` collate utf8_tolower_ci)                     AS `CONSTRAINT_CATALOG`,
        (`sch`.`name` collate utf8_tolower_ci)                     AS `CONSTRAINT_SCHEMA`,
        (convert(`idx`.`name` using utf8) collate utf8_tolower_ci) AS `CONSTRAINT_NAME`,
        (`cat`.`name` collate utf8_tolower_ci)                     AS `TABLE_CATALOG`,
        (`sch`.`name` collate utf8_tolower_ci)                     AS `TABLE_SCHEMA`,
        (`tbl`.`name` collate utf8_tolower_ci)                     AS `TABLE_NAME`,
        (`col`.`name` collate utf8_tolower_ci)                     AS `COLUMN_NAME`,
        `icu`.`ordinal_position`                                   AS `ORDINAL_POSITION`,
        NULL                                                       AS `POSITION_IN_UNIQUE_CONSTRAINT`,
        NULL                                                       AS `REFERENCED_TABLE_SCHEMA`,
        NULL                                                       AS `REFERENCED_TABLE_NAME`,
        NULL                                                       AS `REFERENCED_COLUMN_NAME`
 from (((((`mysql`.`indexes` `idx` join `mysql`.`tables` `tbl`
           on ((`idx`.`table_id` = `tbl`.`id`))) join `mysql`.`schemata` `sch`
          on ((`tbl`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
         on ((`cat`.`id` = `sch`.`catalog_id`))) join `mysql`.`index_column_usage` `icu`
        on ((`icu`.`index_id` = `idx`.`id`))) join `mysql`.`columns` `col`
       on (((`icu`.`column_id` = `col`.`id`) and (`idx`.`type` in ('PRIMARY', 'UNIQUE')))))
 where (can_access_column(`sch`.`name`, `tbl`.`name`, `col`.`name`) and
        is_visible_dd_object(`tbl`.`hidden`, ((`col`.`hidden` <> 'Visible') or `idx`.`hidden` or `icu`.`hidden`))))
union
(select (`cat`.`name` collate utf8_tolower_ci)                    AS `CONSTRAINT_CATALOG`,
        (`sch`.`name` collate utf8_tolower_ci)                    AS `CONSTRAINT_SCHEMA`,
        (convert(`fk`.`name` using utf8) collate utf8_tolower_ci) AS `CONSTRAINT_NAME`,
        (`cat`.`name` collate utf8_tolower_ci)                    AS `TABLE_CATALOG`,
        (`sch`.`name` collate utf8_tolower_ci)                    AS `TABLE_SCHEMA`,
        (`tbl`.`name` collate utf8_tolower_ci)                    AS `TABLE_NAME`,
        (`col`.`name` collate utf8_tolower_ci)                    AS `COLUMN_NAME`,
        `fkcu`.`ordinal_position`                                 AS `ORDINAL_POSITION`,
        `fkcu`.`ordinal_position`                                 AS `POSITION_IN_UNIQUE_CONSTRAINT`,
        `fk`.`referenced_table_schema`                            AS `REFERENCED_TABLE_SCHEMA`,
        `fk`.`referenced_table_name`                              AS `REFERENCED_TABLE_NAME`,
        `fkcu`.`referenced_column_name`                           AS `REFERENCED_COLUMN_NAME`
 from (((((`mysql`.`foreign_keys` `fk` join `mysql`.`tables` `tbl`
           on ((`fk`.`table_id` = `tbl`.`id`))) join `mysql`.`foreign_key_column_usage` `fkcu`
          on ((`fkcu`.`foreign_key_id` = `fk`.`id`))) join `mysql`.`schemata` `sch`
         on ((`fk`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat`
        on ((`cat`.`id` = `sch`.`catalog_id`))) join `mysql`.`columns` `col` on ((`fkcu`.`column_id` = `col`.`id`)))
 where (can_access_column(`sch`.`name`, `tbl`.`name`, `col`.`name`) and
        is_visible_dd_object(`tbl`.`hidden`, (`col`.`hidden` <> 'Visible'))));

